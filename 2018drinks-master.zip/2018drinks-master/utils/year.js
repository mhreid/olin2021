
function getCurrentYear() {
  return new Date().getFullYear()
}

module.exports.getCurrentYear = getCurrentYear;

